
# Variable = King Arthur from Mounty Python's Quest for the Holy Grail (1975)
King_Arthur = ("Sir Arthur, we need to find shrubbery so that the Knights who say Ni will let us pass! ")

# Print Function
print(King_Arthur)

