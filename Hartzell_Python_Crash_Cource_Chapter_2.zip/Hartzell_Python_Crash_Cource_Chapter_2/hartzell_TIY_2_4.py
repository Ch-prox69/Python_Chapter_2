# This variable represents a name
name = "McKinstry"

# Print name in lowercase
print(name.lower())

# Print name in uppercase
print(name.upper())

# Print name in titlecase
print(name.title())