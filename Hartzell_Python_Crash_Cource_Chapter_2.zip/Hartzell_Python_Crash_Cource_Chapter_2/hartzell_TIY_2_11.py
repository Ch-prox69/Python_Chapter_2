# The 2.7 phony-martony program
name = "\tChristopher\tHartzitelli\tis\tMy\tAlternate\tItalian\tIdentity"

# Printing my fake Italian Name with rstrip
print(name.rstrip())

# Printing my fake Italian Name with lstrip
print(name.lstrip())

# Printing my fake Italian with strip
print(name.strip())

# Say hello to Christopher Hartzitelli
print("Hello Everybody")

# The 2.2 Program

# First variable with message from Goldfinger (1964)
super_secret_message = "Do you expect me to talk? No Mr.Bond, I expect you to die!"

# This action prints variable
print(super_secret_message)

# First Variable with the value of the variable changed to output new message
super_secret_message = "Do you expect me to talk?, No Mr.Bond, I expect you to print hello world one-billion times, hahahahaha! "

# This action prints variable with changed value
print(super_secret_message)

# Hello again
print("Hello Mr. Bond")