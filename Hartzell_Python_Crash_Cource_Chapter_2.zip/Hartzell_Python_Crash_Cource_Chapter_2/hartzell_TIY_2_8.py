# Assigning the Value and variable
filename = 'python_notes.txt'

# Removing the prefix
updated_filename = filename.removesuffix('.txt')

# Printing the file name with the updated removeprefix feture
print(updated_filename)