# Famous Quote from Bishop Fulton Sheen
Famous_Quote = "A life is not an accident. It is a responsibility - Bishop Fulton Sheen"

# Printing the famous quote
print(Famous_Quote)
