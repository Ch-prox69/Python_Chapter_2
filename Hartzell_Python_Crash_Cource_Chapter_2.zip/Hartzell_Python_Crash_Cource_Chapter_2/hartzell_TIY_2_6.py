# Variable for famous person which, in this case, is Bishop Fulton Sheen
famous_person = "Bishop Fulton Sheen"

# His message
message = f"{famous_person} - A life is not an accident. It is a responsibility"

# Printing the message 
print(message)