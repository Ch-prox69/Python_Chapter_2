# Favorite Number
variable = 24

# Message that reveals my favorite number
print("My favorite number is...\n" f'{variable}')