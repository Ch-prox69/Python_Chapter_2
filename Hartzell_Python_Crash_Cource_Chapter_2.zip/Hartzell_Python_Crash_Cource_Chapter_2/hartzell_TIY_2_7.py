# Name for our variable
name = "\tChristopher\tHartzitelli\n\tis\tMy\tAlternate\tItalian\tIdentity"

# Printing my fake Italian Name with rstrip
print(name.rstrip())

# Printing my fake Italian Name with lstrip
print(name.lstrip())

# Printing my fake Italian with strip
print(name.strip())