# Addition
addition = 7 + 1
print("The result of the addition problem 7 + 1 is...\n" f'{addition}')

# Subtraction
subtraction = 9 - 1
print("The result of the subtraction problem 9 - 1 is...\n" f'{subtraction}')

# Division
division = 16 / 2
print("The result of the division problem 16 / 2 is...\n" f'{division}')

# Multiplication
multiplication = 2 * 4
print("The result of the multiplication problem 2 * 4 is...\n" f'{multiplication}')